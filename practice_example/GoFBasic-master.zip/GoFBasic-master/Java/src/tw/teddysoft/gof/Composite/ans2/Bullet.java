package tw.teddysoft.gof.Composite.ans2;

public abstract class Bullet extends Weapon {
}
