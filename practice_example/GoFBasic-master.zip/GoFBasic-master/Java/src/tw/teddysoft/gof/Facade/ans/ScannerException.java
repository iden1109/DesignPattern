package tw.teddysoft.gof.Facade.ans;

public class ScannerException extends Exception {
	public ScannerException(String msg) {
		super(msg);
	}
}
