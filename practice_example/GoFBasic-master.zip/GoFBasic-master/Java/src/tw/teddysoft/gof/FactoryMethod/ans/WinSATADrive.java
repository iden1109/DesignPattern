/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.FactoryMethod.ans;

public class WinSATADrive extends Drive {
	public WinSATADrive(int index) {
		super(index);
	}
}
