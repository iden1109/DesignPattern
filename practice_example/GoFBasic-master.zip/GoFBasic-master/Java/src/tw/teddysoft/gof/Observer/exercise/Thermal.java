/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.Observer.exercise;

public class Thermal {
	public Thermal(String ipAddress){}
	public boolean isOverheat(){
		// TODO: 傳回遠端監控設備是否過熱，此類別實作由廠商提供
		return false;
	}
}
