package tw.teddysoft.gof.Facade.ans;

public class Paper {

}
