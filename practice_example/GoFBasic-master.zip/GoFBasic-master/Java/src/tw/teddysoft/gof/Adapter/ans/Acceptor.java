/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.Adapter.ans;

public class Acceptor extends ConfigObject {
	public Acceptor() {
	}
}
