package tw.teddysoft.gof.State.exercise;

public enum CheckResult {
	UP, DOWN;
}
