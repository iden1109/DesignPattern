/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.AbstractFactory.ans;

public class LinuxMonitor extends Monitor {
	public LinuxMonitor(int id){
		super(id);
	}
}
