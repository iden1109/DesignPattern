package tw.teddysoft.gof.Facade.ans;

public class Fax {
	
	public String send(int phoneNumber, Image image) {
		
		return "OK";
	}

}
