package tw.teddysoft.gof.Facade.ans;

public class PrinterException extends Exception {
	public PrinterException(String msg) {
		super(msg);
	}
}
