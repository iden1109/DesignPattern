package tw.teddysoft.gof.State.exercise;
 
public enum HostState {
	UP_HARD, UP_SOFT, 
	DOWN_HARD, DOWN_SOFT ;
}
