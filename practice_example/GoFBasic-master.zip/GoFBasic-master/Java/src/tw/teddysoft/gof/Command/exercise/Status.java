package tw.teddysoft.gof.Command.exercise;

public enum Status {
	PENDING, OK, WARRING, CRITICAL;
}
