/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.FactoryMethod.exercise;

public class SATADrive extends Drive {

	public SATADrive(int index) {
		super(index);
	}
}
