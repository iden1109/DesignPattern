package tw.teddysoft.gof.Facade.exercise;

public class PrinterException extends Exception {
	public PrinterException(String msg) {
		super(msg);
	}
}
