/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.Strategy.ans;

public class Ntfs implements Formater {
	@Override
	public void execute() {
		System.out.println("格式化為NTFS");
	}
}
