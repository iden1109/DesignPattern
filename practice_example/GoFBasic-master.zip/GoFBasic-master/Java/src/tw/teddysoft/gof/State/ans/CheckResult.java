package tw.teddysoft.gof.State.ans;

public enum CheckResult {
	UP, DOWN;
}
