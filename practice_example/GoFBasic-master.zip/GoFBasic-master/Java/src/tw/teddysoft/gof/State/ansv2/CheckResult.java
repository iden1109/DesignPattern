package tw.teddysoft.gof.State.ansv2;

public enum CheckResult {
	UP, DOWN;
}
