/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.ClassFactory.ans;

public class LinuxUSBDrive extends Drive {
	public LinuxUSBDrive(int index) {
		super(index);
	}
}
