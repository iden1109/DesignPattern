/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.AbstractFactory.ans;

public class WinMonitor extends Monitor {
	public WinMonitor(int id){
		super(id);
	}
}
