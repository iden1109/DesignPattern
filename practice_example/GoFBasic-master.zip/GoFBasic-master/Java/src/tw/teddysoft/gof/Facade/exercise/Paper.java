package tw.teddysoft.gof.Facade.exercise;

public class Paper {

}
