/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.AbstractFactory.ans;

public class LinuxIOPort extends IOPort {
	public LinuxIOPort(int address){
		super(address);
	}
}
