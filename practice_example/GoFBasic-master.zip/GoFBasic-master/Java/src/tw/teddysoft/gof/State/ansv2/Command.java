package tw.teddysoft.gof.State.ansv2;

public interface Command {
	CheckResult execute();
}
