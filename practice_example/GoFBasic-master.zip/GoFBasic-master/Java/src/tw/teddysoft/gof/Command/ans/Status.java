package tw.teddysoft.gof.Command.ans;

public enum Status {
	PENDING, OK, WARRING, CRITICAL;
}
