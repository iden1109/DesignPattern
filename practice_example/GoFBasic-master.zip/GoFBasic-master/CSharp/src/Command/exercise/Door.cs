﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.Command.Exercise
{
    public class Door
    {
		public Door(String ipAddress)
		{
		}

		virtual public String getDoorStatus()
		{
			return null;
		}
    }
}
