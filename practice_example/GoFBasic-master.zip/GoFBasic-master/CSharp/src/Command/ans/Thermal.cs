﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.Command.Ans
{
    public class Thermal
	{
		public Thermal(String ipAddress)
		{
		}

		public bool isOverheat()
		{
			// TODO
			return false;
		}
	}
}
