﻿/*
* Copyright 2017 TeddySoft Technology. 
* 
*/
using System;

namespace Tw.Teddysoft.Gof.FactoryMethod.Ans
{
    public class WinUSBDrive : Drive
	{
	    public WinUSBDrive(int imp) : base(imp)
	    {
	    }
    }
}
