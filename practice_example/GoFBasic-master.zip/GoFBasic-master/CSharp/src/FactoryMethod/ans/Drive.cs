﻿/*
* Copyright 2017 TeddySoft Technology. 
* 
*/
using System;

namespace Tw.Teddysoft.Gof.FactoryMethod.Ans
{
    public class Drive
	{
		public Drive(int imp)
		{
		}

        public void updateFreeSpace() { }

        public void doQuickSMARTCheck() { }
	}
}
