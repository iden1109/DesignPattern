﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.FactoryMethod.Exercise
{
    public class USBDrive : Drive
	{
        public USBDrive(int imp) : base(imp)
		{
		}
	}
}
