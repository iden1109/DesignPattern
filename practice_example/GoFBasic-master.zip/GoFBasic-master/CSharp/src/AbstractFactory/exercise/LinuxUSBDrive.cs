﻿/*
 * Copyright 2017 TeddySoft Technology.
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.AbstractFactory.Exercise
{
    public class LinuxUSBDrive : Drive
    {
        public LinuxUSBDrive(int imp) : base (imp)
        {
        }
    }
}
