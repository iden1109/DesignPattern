﻿/*
 * Copyright 2017 TeddySoft Technology.
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.AbstractFactory.Ans
{
    public class LinuxMonitor : Monitor
    {

    public LinuxMonitor(int id) : base(id)
    {
    }
}

}
