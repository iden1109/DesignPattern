﻿/*
 * Copyright 2017 TeddySoft Technology.
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.AbstractFactory.Ans
{
    public class WinUSBDrive : Drive
	{
    	public WinUSBDrive(int imp) : base(imp)
	    {
	    }
    }
}
