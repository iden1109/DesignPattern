﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;
using NUnit.Framework;

namespace Tw.Teddysoft.Gof.Strategy.Exercise
{
    public enum FileSystemEnum
    {
        NTFS, FAT32, FAT
    }
}
