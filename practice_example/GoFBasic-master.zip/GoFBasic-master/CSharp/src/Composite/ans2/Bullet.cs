﻿/*
 * Copyright 2017 TeddySoft Technology. 
 *
 */
using System;
using System.Collections.Generic;

namespace Tw.Teddysoft.Gof.Composite.Ans2
{
    public abstract class Bullet : Weapon
	{
    }
}
