﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.Facade.Exercise
{
    public class Image
    {
        public Image()
        {
        }
    }
}
