﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.Facade.Exercise
{
    public class Paper
    {
        public Paper()
        {
        }
    }
}
