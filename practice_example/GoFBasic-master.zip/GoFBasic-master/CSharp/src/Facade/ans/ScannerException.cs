﻿﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.Facade.Ans
{
    public class ScannerException : Exception
	{
        public ScannerException(String msg) : base(msg)
		{
		}
    }
}
