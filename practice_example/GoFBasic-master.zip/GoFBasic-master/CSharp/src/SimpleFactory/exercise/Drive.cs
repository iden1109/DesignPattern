﻿/*
* Copyright 2017 TeddySoft Technology. 
* 
*/
using System;

namespace Tw.Teddysoft.Gof.SimpleFactory.Exercise
{
    public class Drive
	{
		public Drive(int imp) {}
		public void updateFreeSpace() { }
		public void doQuickSMARTCheck() { }
	}
}
