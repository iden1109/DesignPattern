﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.SimpleFactory.Exercise
{
	public class USBDrive : Drive
	{
        public USBDrive(int imp) : base(imp)
		{
		}
	}
}
